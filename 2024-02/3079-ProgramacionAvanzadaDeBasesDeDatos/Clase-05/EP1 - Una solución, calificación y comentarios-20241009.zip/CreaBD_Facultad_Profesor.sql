USE master;
-- opcional


IF EXISTS (SELECT name FROM sys.sysdatabases WHERE name = 'Facultad')
	DROP DATABASE Facultad;
-- opcional

CREATE DATABASE Facultad;
go

USE Facultad;

CREATE TABLE Carrera(
	codCarrera smallint not null CONSTRAINT PK_Carrera PRIMARY KEY,
	nomCarrera varchar(75) not null CONSTRAINT U_nomCarrera UNIQUE,
	fecCreacion date not null );

CREATE TABLE Curso(
	codCurso integer not null CONSTRAINT PK_Curso PRIMARY KEY,
	nomCurso varchar(75) not null CONSTRAINT U_nomCurso UNIqUE,
	creditos tinyint not null );

CREATE TABLE MallaCurricular( 
	codCarrera smallint not null CONSTRAINT FK_MallaCurricular_Carrera
		FOREIGN KEY REFERENCES Carrera,
	codCurso integer not null CONSTRAINT FK_MallaCurricular_Curso
		FOREIGN KEY REFERENCES Curso,
	ciclo tinyint not null,
	codPreRequisito integer null CONSTRAINT FK_MallaCurricular_CursoPre
		FOREIGN KEY REFERENCES Curso
	CONSTRAINT PK_MallaCurricular PRIMARY KEY(codCarrera, codCurso)	);

CREATE TABLE Profesor(
	codProfesor integer not null CONSTRAINT PK_Profesor PRIMARY KEY,
	apellido varchar(35) not null,
	nombre varchar(35) not null,
	tipoDoc varchar(5) not null CONSTRAINT DF_tipoDoc DEFAULT 'DNI',
	numDoc varchar(10) not null );

CREATE TABLE Asignacion(
	codCurso integer not null CONSTRAINT FK_Asignacion_Curso
		FOREIGN KEY REFERENCES Curso,
	codProfesor integer not null CONSTRAINT FK_Asignacion_Profesor
		FOREIGN KEY REFERENCES Profesor,
	diaSemana char(2) null CONSTRAINT CHK_diaSemana
		CHECK (diaSemana IN ('LU','MA','MI','JU','VI','SA')),
	horaInicio tinyint null CONSTRAINT CHK_horaInicio
		CHECK (horaInicio IS NULL OR (horaInicio BETWEEN 7 AND 20)),
	horaFin tinyint null CONSTRAINT CHK_horaFin
		CHECK (horaFin IS NULL OR (horaFin <= 22)),
	CONSTRAINT CHK_duracionClase CHECK (horaFin > horaInicio),
	CONSTRAINT PK_Asignacion PRIMARY KEY (codCurso, codProfesor) );





