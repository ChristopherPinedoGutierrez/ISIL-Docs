USE GlobalTech;

/*
Generar el cat�logo de la empresa
*/
SELECT Producto.codProducto, Producto.nomProducto,
	Producto.fabricante, Producto.marca,
	Producto.codSubcategoria, Subcategoria.nomSubcategoria,
	Subcategoria.codCategoria, Categoria.nomCategoria
FROM Producto
INNER JOIN Subcategoria
	ON Producto.codSubcategoria = Subcategoria.codSubcategoria
INNER JOIN Categoria
	ON Subcategoria.codCategoria = Categoria.codCategoria;

-- El listado anterior muestra los atributos de los productos
-- que la empresa vende.
--
-- El cliente est� interesado en adquirir una computadora.
-- Modifique la consulta para que muestre la informaci�n
-- que le interesa a este cliente.
SELECT Producto.codProducto, Producto.nomProducto,
	Producto.fabricante, Producto.marca,
	Producto.codSubcategoria, Subcategoria.nomSubcategoria,
	Subcategoria.codCategoria, Categoria.nomCategoria
FROM Producto
INNER JOIN Subcategoria
	ON Producto.codSubcategoria = Subcategoria.codSubcategoria
INNER JOIN Categoria
	ON Subcategoria.codCategoria = Categoria.codCategoria
WHERE Categoria.nomCategoria = 'Computers';

-- El cliente est� interesado solo en las computadoras
-- de la marca Contoso.
SELECT Producto.codProducto, Producto.nomProducto,
	Producto.fabricante, Producto.marca,
	Producto.codSubcategoria, Subcategoria.nomSubcategoria,
	Subcategoria.codCategoria, Categoria.nomCategoria
FROM Producto
INNER JOIN Subcategoria
	ON Producto.codSubcategoria = Subcategoria.codSubcategoria
INNER JOIN Categoria
	ON Subcategoria.codCategoria = Categoria.codCategoria
WHERE Categoria.nomCategoria = 'Computers'
	AND Producto.marca = 'Contoso';

-- Otro cliente est� interesado en computadoras de la marca Datum
SELECT Producto.codProducto, Producto.nomProducto,
	Producto.fabricante, Producto.marca,
	Producto.codSubcategoria, Subcategoria.nomSubcategoria,
	Subcategoria.codCategoria, Categoria.nomCategoria
FROM Producto
INNER JOIN Subcategoria
	ON Producto.codSubcategoria = Subcategoria.codSubcategoria
INNER JOIN Categoria
	ON Subcategoria.codCategoria = Categoria.codCategoria
WHERE Categoria.nomCategoria = 'Computers'
	AND Producto.marca = 'Datum';

-- En la base de datos hay computadoras Datum, pero esta cadena es
-- parte del nombre de la marca. No nos acordamos del nombre completo
-- de la marca. �C�mo ubicamos la marca sin tener que usar el
-- nombre completo?
SELECT Producto.codProducto, Producto.nomProducto,
	Producto.fabricante, Producto.marca,
	Producto.codSubcategoria, Subcategoria.nomSubcategoria,
	Subcategoria.codCategoria, Categoria.nomCategoria
FROM Producto
INNER JOIN Subcategoria
	ON Producto.codSubcategoria = Subcategoria.codSubcategoria
INNER JOIN Categoria
	ON Subcategoria.codCategoria = Categoria.codCategoria
WHERE Categoria.nomCategoria = 'Computers'
	AND Producto.marca LIKE '%Datum%';

-- No hay computadoras de la marca Datum


-- �Para qu� categor�as existe la marca Datum?
SELECT Producto.codProducto, Producto.nomProducto,
	Producto.fabricante, Producto.marca,
	Producto.codSubcategoria, Subcategoria.nomSubcategoria,
	Subcategoria.codCategoria, Categoria.nomCategoria
FROM Producto
INNER JOIN Subcategoria
	ON Producto.codSubcategoria = Subcategoria.codSubcategoria
INNER JOIN Categoria
	ON Subcategoria.codCategoria = Categoria.codCategoria
WHERE Producto.marca LIKE '%Datum%';

-- Esta consulta entrega demasiada informaci�n.
-- Escriba una consulta m�s simple qu� muestre en qu� categor�as
-- existe la marca Datum
SELECT DISTINCT Producto.marca, Categoria.nomCategoria
FROM Producto
INNER JOIN Subcategoria
	ON Producto.codSubcategoria = Subcategoria.codSubcategoria
INNER JOIN Categoria
	ON Subcategoria.codCategoria = Categoria.codCategoria
WHERE Producto.marca LIKE '%Datum%';

-- Obtener una lista de los productos que se han vendido a un precio
-- superior a 2500
SELECT DISTINCT Producto.nomProducto, Ventas.precio
FROM Producto
INNER JOIN Ventas ON Producto.codProducto = Ventas.codProducto
WHERE Ventas.precio > 2500;

-- Obtener un listado de productos cuyo precio de venta se encuentra
-- en el rango de 1500 a 2500
SELECT DISTINCT Producto.nomProducto, Ventas.precio
FROM Producto
INNER JOIN Ventas ON Producto.codProducto = Ventas.codProducto
WHERE Ventas.precio >= 1500 AND Ventas.precio <= 2500;

SELECT DISTINCT Producto.nomProducto, Ventas.precio
FROM Producto
INNER JOIN Ventas ON Producto.codProducto = Ventas.codProducto
WHERE Ventas.precio BETWEEN 1500 AND 2500;

-- Obtener un listado de los pedidos ejecutados en
-- China, Syria, Singapore e Iran
SELECT Ventas.numPedido, Ubicacion.pais
FROM Ventas
INNER JOIN Ubicacion ON Ventas.codUbicacion = Ubicacion.codUbicacion
WHERE Ubicacion.pais = 'China' OR Ubicacion.pais = 'Syria'
	OR Ubicacion.pais = 'Singapore' OR Ubicacion.pais = 'Iran';

SELECT Ventas.numPedido, Ubicacion.pais
FROM Ventas
INNER JOIN Ubicacion ON Ventas.codUbicacion = Ubicacion.codUbicacion
WHERE Ubicacion.pais IN ('China','Syria','Singapore','Iran');




