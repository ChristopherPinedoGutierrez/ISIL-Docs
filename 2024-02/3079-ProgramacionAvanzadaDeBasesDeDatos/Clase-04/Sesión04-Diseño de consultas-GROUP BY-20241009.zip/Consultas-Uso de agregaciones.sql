/* Funciones de agregaci�n
Una funci�n de agregaci�n permite consolidar un conjunto de valores
en un solo valor. Las funciones de agregaci�n m�s utilizadas:
SUM(col | exp)
AVG(col | exp)
COUNT(col | exp)
MAX(col | exp)
MIN(col | exp)
*/
USE GlobalTech;

-- Cantidad de pedidos ejecutados en China
SELECT count(Ventas.numPedido)
FROM Ventas
INNER JOIN Ubicacion ON Ventas.codUbicacion = Ubicacion.codUbicacion
WHERE Ubicacion.pais = 'China';

-- Precio de venta promedio de las computadoras
SELECT avg(Ventas.precio)
FROM Ventas
INNER JOIN Producto ON Ventas.codProducto = Producto.codProducto
INNER JOIN Subcategoria ON Producto.codSubcategoria = Subcategoria.codSubcategoria
INNER JOIN Categoria ON Subcategoria.codCategoria = Categoria.codCategoria
WHERE Categoria.nomCategoria = 'Computers';

-- Monto total de dinero ingresado por la venta de computadoras
SELECT sum(Ventas.montoVenta)
FROM Ventas
INNER JOIN Producto ON Ventas.codProducto = Producto.codProducto
INNER JOIN Subcategoria ON Producto.codSubcategoria = Subcategoria.codSubcategoria
INNER JOIN Categoria ON Subcategoria.codCategoria = Categoria.codCategoria
WHERE Categoria.nomCategoria = 'Computers';

/* CONSULTAS GROUP BY
Permiten agrupar un conjunto de registros en base al valor de
una columna (formaci�n de grupos).

SELECT listaColumnas, funcAgr(...)
FROM tablas
[WHERE filtroFilas]
GROUP BY listaColumnas
[HAVING filtroGrupos]
[ORDER BY columna(s)];

SELECT listaColumnas y GROUP BY listaColumnas deben tener las
mismas columnas
*/
USE GlobalTech;

-- �Cu�ntos productos tenemos registrados para cada categor�a?
SELECT Categoria.nomCategoria, COUNT(Producto.codProducto)
FROM Producto
INNER JOIN Subcategoria ON Producto.codSubcategoria = Subcategoria.codSubcategoria
INNER JOIN Categoria ON Subcategoria.codCategoria = Categoria.codCategoria
GROUP BY Categoria.nomCategoria;

SELECT COUNT(codProducto)
FROM Producto;

-- �Cu�l es el precio promedio de cada categor�a?
SELECT Categoria.nomCategoria, avg(Producto.precio)
FROM Producto
INNER JOIN Subcategoria ON Producto.codSubcategoria = Subcategoria.codSubcategoria
INNER JOIN Categoria ON Subcategoria.codCategoria = Categoria.codCategoria
GROUP BY Categoria.nomCategoria;

-- Como el precio no est� registrado en la tabla Producto,
-- la consulta anterior no es v�lida.
-- El precio est� registrado en la tabla Ventas.
-- Para obtener el precio, debemos combinar la consulta anterior
-- con la tabla Ventas.
SELECT Categoria.nomCategoria, avg(Ventas.precio) AS PrecioPromedio
FROM Producto
INNER JOIN Subcategoria ON Producto.codSubcategoria = Subcategoria.codSubcategoria
INNER JOIN Categoria ON Subcategoria.codCategoria = Categoria.codCategoria
INNER JOIN Ventas ON Producto.codProducto = Ventas.codProducto
GROUP BY Categoria.nomCategoria;

-- �Cu�ntos pedidos se han registrado por cada canal de ventas?
SELECT canal, count(numPedido)
FROM Ventas
GROUP BY canal;

-- �Cu�nto es el monto de dinero ingresado por cada canal de ventas?
SELECT canal, sum(montoVenta)
FROM Ventas
GROUP BY canal;

-- �Cu�nto es el dinero ingresado por las ventas realizadas a cada ciudad?
SELECT Ubicacion.ciudad, sum(Ventas.montoVenta)
FROM Ventas
INNER JOIN Ubicacion ON Ventas.codUbicacion = Ubicacion.codUbicacion
GROUP BY Ubicacion.ciudad;
-- Esta consulta no entrega necesariamente el resultado real.
-- Si un mismo nombre de ciudad est� registrado para varios pa�ses,
-- la consulta sumar� las ventas de dicha ciudad en dichos pa�ses.

SELECT Ubicacion.pais, Ubicacion.ciudad, sum(Ventas.montoVenta)
FROM Ventas
INNER JOIN Ubicacion ON Ventas.codUbicacion = Ubicacion.codUbicacion
GROUP BY Ubicacion.pais, Ubicacion.ciudad;

-- �Cu�nto es el monto de dinero ingresado por cada canal de ventas
-- para los productos de la categor�a C04?
SELECT Ventas.canal, sum(Ventas.montoVenta)
FROM Ventas
INNER JOIN Producto ON Ventas.codProducto = Producto.codProducto
INNER JOIN Subcategoria ON Producto.codSubcategoria = Subcategoria.codSubcategoria
WHERE Subcategoria.codCategoria = 'C04'
GROUP BY Ventas.canal;

























