USE Formula1;

-- Generar el ranking de pilotos de la temporada 2021
SELECT TOP 10 WITH TIES Resultado.idPiloto, Piloto.apellido, Piloto.nombre, 
	sum(Resultado.puntos) AS Puntaje
FROM Resultado
INNER JOIN Piloto ON Resultado.idPiloto = Piloto.idPiloto
INNER JOIN Carrera ON Resultado.idCarrera = Carrera.idCarrera
WHERE Carrera.temporada = 2021
GROUP BY Resultado.idPiloto, Piloto.apellido, Piloto.nombre
ORDER BY Puntaje DESC;

-- Obtener un listado que muestre a los pilotos que han ganado la
-- carrera 'Australian Grand Prix'. La lista debe mostrar
-- cu�ntas veces gan� cada piloto en dicha carrera.
SELECT Piloto.apellido, Piloto.nombre, count(Resultado.posicionFinal)
FROM Resultado
INNER JOIN Piloto ON Resultado.idPiloto = Piloto.idPiloto
INNER JOIN Carrera ON Resultado.idCarrera = Carrera.idCarrera
WHERE Carrera.nomCarrera = 'Australian Grand Prix'
	AND Resultado.posicionFinal = 1
GROUP BY Piloto.apellido, Piloto.nombre;

-- En la tabla Resultado la columna grillaSalida indica en qu�
-- posici�n parti� el piloto, y la columna posicionFinal en qu�
-- posici�n lleg� al final de la carrera.
-- Generar un listado de los pilotos que en una carrera han 
-- rebasado a al menos 10 pilotos al finalizar la carrera.
-- La lista debe mostrar: apellido y nombre del piloto,
-- grillaSalida, posicionFinal, posiciones rebasadas,
-- nombre de la carrera y temporada.
SELECT Piloto.apellido, Piloto.nombre, Carrera.nomCarrera,
	Carrera.temporada,
	Resultado.grillaSalida, Resultado.posicionFinal,
	Resultado.grillaSalida - Resultado.posicionFinal AS posicionesRebasadas
FROM Resultado
INNER JOIN Piloto ON Resultado.idPiloto = Piloto.idPiloto
INNER JOIN Carrera ON Resultado.idCarrera = Carrera.idCarrera
WHERE (Resultado.grillaSalida > Resultado.posicionFinal)
	AND ((Resultado.grillaSalida - Resultado.posicionFinal) >= 10)
ORDER BY posicionesRebasadas DESC;







